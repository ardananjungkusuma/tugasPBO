package tes;

/**
 *
 * @author ardan
 */
public class Elektronik {
    private int voltase;

    public Elektronik() {
        this.voltase = 220;
    }

    public int getVoltase() {
        return voltase;
    }
}
