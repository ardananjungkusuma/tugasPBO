package tes;

/**
 *
 * @author ardan
 */
public class TelevisiJadul extends Elektronik{
    private String modeInput;

    public TelevisiJadul() {
        this.modeInput = "DVI";
    }

    public String getModeInput() {
        return modeInput;
    }

    
    
}
