package tes;

/**
 *
 * @author ardan
 */
public class TelevisiModern extends Elektronik{
    private String modeInput;

    public TelevisiModern() {
        this.modeInput="HDMI";
    }

    public String getModeInput() {
        return modeInput;
    }
    
    
}
